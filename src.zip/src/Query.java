import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import org.apache.commons.io.FileUtils;


public class Query {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		TDB tdb = new TDB();
		
		Scanner input = new Scanner(System.in);
		String query = input.nextLine();
		
		System.out.println("Querying " + query + " in the database");
		
		tdb.queryTDB(query);
//			tdb.checkTDB();

		
		input.close();

	}

}
