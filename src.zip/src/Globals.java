import module.graph.ParserHelper;


public class Globals {

	public static String rdf_path = "/home/pixel/mallikarjun/datasets/rdf_annotations/";
	public static String tdb_path = "/home/pixel/mallikarjun/datasets/tdb";
	
	
	
	
	// Namespaces to be used for the nodes and their edges resp.
	public static String res = "resource:";
	public static String prop = "property:";
}
