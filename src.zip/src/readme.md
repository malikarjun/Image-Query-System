Use Rules function 
	QueryExpansion:createSPARQLQuery
	TDB:addModel
